

<?php $__env->startPush('content'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patri\Herd\blog\resources\views/dashboard/index.blade.php ENDPATH**/ ?>