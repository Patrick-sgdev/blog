@extends('dashboard.layouts.dashboard')

@push('content')

@endpush
